/** ------ effect state ------- **/

var rot = 1.0;

if (!Object.keys) {
    Object.keys = function (obj) {
        var keys = [],
            k;
        for (k in obj) {
            if (Object.prototype.hasOwnProperty.call(obj, k)) {
                keys.push(k);
            }
        }
        return keys;
    };
}

Array.prototype.includes||Object.defineProperty(Array.prototype,"includes",{value:function(r,e){if(null==this)throw new TypeError('"this" is null or not defined');var t=Object(this),n=t.length>>>0;if(0===n)return!1;var i,o,a=0|e,u=Math.max(0<=a?a:n-Math.abs(a),0);for(;u<n;){if((i=t[u])===(o=r)||"number"==typeof i&&"number"==typeof o&&isNaN(i)&&isNaN(o))return!0;u++}return!1}});

var effectData = {
    reservedMeshId: {
        retouch: 0,
        transparentBgSeparationMesh: 6,
        bgSeparationMesh: 7,
        blurBgMesh: 8,
    },

    meshes: {
        retouch : "!glfx_FACE",
        bgTransparent: "tri_transparent.bsm2",
        bgSeparation: "triBG2.bsm2",
        blurBg: "tri_Blur.bsm2",
    },

    faceTrackerData: {
      active: false
    },

    shadersIDs: {
        softlightAlpha: 0,
        angle: 1,
        makeupApply: 2,
        bg_plane_mode: 3,
        js_texture_size: 4,
        bgTextureAlpha: 6,
        bgAlpha: 7,
        bgRotation: 8,
        bgScale: 9,
        platformData: 10,
        makeupType: 15,
        blurRadius: 16,
    },

    retouchTexturesIDs: {
        softLight: 0,
        makeup: 1
    },

    makeupsData: {
        isInitialized: false,
        makeups: { // makeups[id][0] - texture name, makeups[id][1] - texture type (0 - half, 1 - full).
            "Empty": { type: 0, tex_name: "MakeupNull.png" },
        }
    },

    meshesState: {
        bgSeparationTransparentCreated: false,
        bgSeparationCreated: false,
        bgBlurCreated: false,
    },

    bgState: {
        lastAngle: 0,
        currAngle: 0,
        lastScale: 0,
        currScale: 1,
        bgScale: 1,
        textureTransparency: 1,
        bgTransparency: 1,
    },

    interpolation: {
        morph_cheeks_str: {
            "0.0": 0.0,
            "0.4": 0.3,
            "0.8": 0.8,
            "1.0": 1.0
        },
        morph_eyes_str: {
            "0.0": 0.0,
            "0.4": 0.1,
            "0.8": 0.5,
            "1.0": 1.0
        },
        morph_nose_str: {
            "0.0": 0.0,
            "0.4": 0.2,
            "0.8": 0.6,
            "1.0": 1.0
        },
        skin_soft_str: {
            "0.0": 0.0,
            "0.4": 0.7,
            "0.8": 0.9,
            "1.0": 1.0
        },
        softlight_alpha: {
            "0.0": 0.0,
            "0.4": 0.7,
            "0.8": 1.0,
            "1.0": 1.0
        },
        eyes_coloring_str: {
            "0.0": 0.0,
            "0.4": 0.8,
            "0.8": 1.0,
            "1.0": 1.0
        }
    },

    luts_path: "beauty_luts/",

    softlight_textures: ["soft.ktx"],

    eyes_lut: "lut3d_eyes_verylow.png",

    teeth_highlight_lut : "lut3d_teeth_highlighter5.png",
};

var beautifyingProps = {
    morph_cheeks_str: 0.0,
    morph_eyes_str: 0.0,
    morph_nose_str: 0.0,

    skin_soft_str: 0.0,
    softlight_alpha: 0.0,
    softlight_tex: 0,

    eyes_coloring_str: 0.0,

    teeth_whitening_str: 0.0
};


/** ------ effect ------- **/

function Effect()
{
    var self = this;

    this.init = function() {
        var retouchMeshId = effectData.reservedMeshId.retouch;
        Api.meshfxMsg("spawn", retouchMeshId, 0, effectData.meshes.retouch);
        Api.showRecordButton();
        updateEffect();

        var makeupTypeShaderVarId = effectData.shadersIDs.makeupType;
        Api.meshfxMsg("shaderVec4", 0, makeupTypeShaderVarId, effectData.makeupsData.makeups["Empty"].type + " 0.0 0.0 0.0");

        var makeupTexId = effectData.retouchTexturesIDs.makeup;
        Api.meshfxMsg("tex", retouchMeshId, makeupTexId, effectData.makeupsData.makeups["Empty"].tex_name);

        var makeupApplyShaderVarId = effectData.shadersIDs.makeupApply;
        Api.meshfxMsg("shaderVec4", 0, makeupApplyShaderVarId, "0.0 0.0 0.0 0.0");

        Api.meshfxMsg("shaderVec4", 0, effectData.shadersIDs.platformData, Api.getPlatform().toLowerCase() == "android" ? "0 0 0 0"  : "1 0 0 0" );

        // initBlurBackground("true");

        initBackground("true");
        setBackgroundTexture("images/bg_image.jpg");

        // initTransparentBG("true");

        onDataUpdate(1);
    };

    this.restart = function() {
        Api.meshfxReset();
        self.init();
    };

    this.faceActions = [track_angle];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [];
}

var effect = new Effect();

/** ----- effect update ----- **/

function updateEffect() {  
    applySoftlightAlpha(); // TODO: fix Api.modelview() matrix
    applySkinSofting();
    applysoftLight();
    applyCheeksMorphing();
    applyEyesMorphing();
    applyNoseMorphing();
    applyEyesColoring();
    applyTeethWhitening();
}

function interpolatedValue(param, value) {
    settings = effectData.interpolation[param];
    if (settings !== undefined) {
        if (value < 0.4) { // 0 - 40%
            return interpolate(0, settings["0.0"], 0.4, settings["0.4"], value);
        } else if (value < 0.8) {// 40 - 80%
            return interpolate(0.4, settings["0.4"], 0.8, settings["0.8"], value);
        } else { // 80 - 100%
            return interpolate(0.8, settings["0.8"], 1.0, settings["1.0"], value);
        }
    } else {
        return value;
    }
}

function interpolate(x1, fx1, x2, fx2, x) {
    return fx1 + (fx2 - fx1) * (x - x1) / (x2 - x1);
}

function track_angle() {
    if (typeof Api.modelview != 'undefined'){
        var mv = Api.modelview();
        rot = Math.min(Math.max((mv[6] + 0.15) / (0.15 - 0.01), 0.0), 1.0);
    } else {
        var mv = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
        rot = 0.;
    }
    var skinSoftStr = beautifyingProps.skin_soft_str;
    var trackedValue = skinSoftStr + " 0.0 " + rot;
    var angleShaderVarId = effectData.shadersIDs.angle;
    Api.meshfxMsg("shaderVec4", 0, angleShaderVarId, trackedValue);
}

function applySkinSofting() {
    var skinSofStr = beautifyingProps.skin_soft_str;
    skinSofStr = interpolatedValue("skin_soft_str", skinSofStr);
    var shaderValue = skinSofStr + " 0.0 " + rot;
    var angleShaderVarId = effectData.shadersIDs.angle;
    Api.meshfxMsg("shaderVec4", 0, angleShaderVarId, shaderValue);
}

function applyCheeksMorphing() {
    var cheeksMorphStr = beautifyingProps.morph_cheeks_str;
    cheeksMorphStr = interpolatedValue("morph_cheeks_str", cheeksMorphStr);
    Api.meshfxMsg("beautyMorph", 0, cheeksMorphStr * 100, "face");
}

function applyEyesMorphing() {
    var eyesMorphStr = beautifyingProps.morph_eyes_str;
    eyesMorphStr = interpolatedValue("morph_eyes_str", eyesMorphStr);
    Api.meshfxMsg("beautyMorph", 0, eyesMorphStr * 200, "eyes");
}

function applyNoseMorphing() {
    var noseMorphStr = beautifyingProps.morph_nose_str;
    noseMorphStr = interpolatedValue("morph_nose_str", noseMorphStr);
    Api.meshfxMsg("beautyMorph", 0, noseMorphStr * 100, "nose");
}

function applysoftLight() {
    var softLightTexIdx = beautifyingProps.softlight_tex;
    var softLightTexture = effectData.softlight_textures[softLightTexIdx];

    var softTexId = effectData.retouchTexturesIDs.softLight;
    var retouchMatId = effectData.reservedMeshId.retouch;

    Api.meshfxMsg("tex", retouchMatId, softTexId, softLightTexture);
}

function applyEyesColoring() {
    var eyesColoringStr = beautifyingProps.eyes_coloring_str;
    eyesColoringStr = interpolatedValue("eyes_coloring_str", eyesColoringStr);

    var eyesColoringLutTex = effectData.eyes_lut;
    var eyesColoringLutPath = effectData.luts_path + eyesColoringLutTex;

    Api.meshfxMsg("wlut", 1, eyesColoringStr * 50, eyesColoringLutPath);
}

function applyTeethWhitening() {
    var teethWhiteningStr = beautifyingProps.teeth_whitening_str * 100;
    var teetLutTexPath = effectData.luts_path + effectData.teeth_highlight_lut;
    Api.meshfxMsg("wlut", 2, teethWhiteningStr, teetLutTexPath);
}

function applySoftlightAlpha() {
    var softlightAlpha =  beautifyingProps.softlight_alpha;
    softlightAlpha = interpolatedValue("softlight_alpha", softlightAlpha);

    var softLightVal = "0.0 " + softlightAlpha + " 0.0 0.0";
    var softlightAlphaShaderVarId = effectData.shadersIDs.softlightAlpha;

    Api.meshfxMsg("shaderVec4", 0, softlightAlphaShaderVarId, softLightVal);
}

// BG transparent API

function initTransparentBG(modifyRecognizerFeatures) {
    if (modifyRecognizerFeatures && !effectData.meshesState.bgSeparationTransparentCreated && !effectData.meshesState.bgBlurCreated && !effectData.meshesState.bgSeparationCreated){
        Api.print("initTransparentBG - transparent BG separation initialized");

        effectData.meshesState.bgSeparationTransparentCreated = true;
        var id = effectData.reservedMeshId.transparentBgSeparationMesh;

        var meshName = effectData.meshes.bgTransparent;
        Api.meshfxMsg("spawn", id, 0, meshName);

        setBGTransparency(0.);
    } else {
        Api.print("initTransparentBG - transparent BG separation can't be initialized");
    }
}

function deleteTransparentBG(modifyRecognizerFeatures) {
    if (effectData.meshesState.bgSeparationTransparentCreated && modifyRecognizerFeatures) {
        Api.print("deleteTransparentBackground - transparent BG deactivated");
        Api.meshfxMsg("del", effectData.reservedMeshId.transparentBgSeparationMesh);
        effectData.meshesState.bgSeparationTransparentCreated = false;
    } else {
        Api.print("deleteTransparentBackground - transparent BG is already deactivated");
    }
}

// Blur bg API

function initBlurBackground(modifyRecognizerFeatures) {
    if (modifyRecognizerFeatures && !effectData.meshesState.bgBlurCreated && !effectData.meshesState.bgSeparationCreated) {
        Api.print("initBlurBackground - add Blur bg separation mesh");

        var id = effectData.reservedMeshId.blurBgMesh;
        var meshName = effectData.meshes.blurBg;
        Api.meshfxMsg("spawn", id, 0, meshName);

        setBlurRadius(0.5);

        effectData.meshesState.bgBlurCreated = true;
    } else {
        Api.print("initBlurBackground - cannot initialize already initialized Blur bg mesh");
    }
}

function setBlurRadius(floatRadius){
    if (floatRadius > 1 || floatRadius < 0) {
        Api.print("setBlurRadius - set radius in range [0.,1.] as float value. Where 0. is minimal radius value (but still blurry).");
    } else {
        var blurShaderId = effectData.shadersIDs.blurRadius;
        var radius = 3 + 5 * floatRadius;
        Api.meshfxMsg("shaderVec4", 0, blurShaderId, radius + " 0 0 0");
        Api.print("setBlurRadius - radius is set to " + radius);
    }
}


function deleteBlurBackground(modifyRecognizerFeatures) {
    if (effectData.meshesState.bgBlurCreated && modifyRecognizerFeatures) {
        Api.print("deleteBlurBackground - remove Blur bg separation mesh");
        Api.meshfxMsg("del", effectData.reservedMeshId.blurBgMesh);

        effectData.meshesState.bgBlurCreated = false; // ---------------------------<
    } else {
        Api.print("deleteBlurBackground - cannot delete already deleted Blur bg separation mesh");
    }
}

// BG texture/video API

function initBackground(modifyRecognizerFeatures) {
    if (modifyRecognizerFeatures && !effectData.meshesState.bgSeparationCreated && !effectData.meshesState.bgBlurCreated) {
        Api.print("initBackground - add bg separation mesh");

        var id = effectData.reservedMeshId.bgSeparationMesh;
        var meshName = effectData.meshes.bgSeparation;
        Api.meshfxMsg("spawn", id, 0, meshName);

        effectData.meshesState.bgSeparationCreated = true;
    } else {
        Api.print("initBackground - cannot initialize already initialized bg mesh");
    }

    setBgRotation(effectData.bgState.currAngle);
    setBgScale(1);
}

function resetBgState() {
    effectData.bgState.bgScale = 1.0;
    effectData.bgState.currAngle = 0;
    setBgRotation(effectData.bgState.currAngle);
    setBgScale(effectData.bgState.bgScale);
    setBGTransparency(1.);
    setTextureTransparency(1.);
}

function setBackgroundTexture(textureName) {
    if (!effectData.meshesState.bgSeparationCreated) {
        Api.print("cannot set bg texture because mesh is not created");
        return;
    } else {
        Api.print("setBackgroundTexture - texture " + textureName + " is set.");
    }
    resetBgState();

    var bg_texture_image =  bnb.scene.getAssetManager().findImage("bg_image");

    if(bg_texture_image){
        bg_texture_image.asTexture().load(textureName);
    }

    var width = bg_texture_image.asTexture().getWidth();
    var height = bg_texture_image.asTexture().getHeight();

    Api.print("width: " + width + ", height: " + height);

    Api.meshfxMsg("shaderVec4", 0, effectData.shadersIDs.js_texture_size, width + " " + height + " 0 0" );
    
    Api.meshfxMsg("shaderVec4", 0, effectData.shadersIDs.bg_plane_mode, "0 0 0 0");
}

function setBackgroundVideo(filePath) {
    if (!effectData.meshesState.bgSeparationCreated) {
        Api.print("cannot set bg video because mesh is not created");
        return;
    } else {
        Api.print("setBackgroundVideo - video file " + filePath + " is set.");
    }
   
    resetBgState();

    var bg_video_file =  bnb.scene.getAssetManager().findImage("frx");
    bg_video_file.asVideo().load(filePath);

    var width = bg_video_file.asVideo().getWidth();
    var height = bg_video_file.asVideo().getHeight();

    Api.meshfxMsg("shaderVec4", 0, effectData.shadersIDs.js_texture_size, width + " " + height + " 0 0" );
    Api.meshfxMsg("shaderVec4", 0, effectData.shadersIDs.bg_plane_mode, "1 0 0 0");
    Api.meshfxMsg("tex", effectData.reservedMeshId.bgSeparationMesh, 0, "empty.png");
    Api.playVideo("frx", true, 1);
}

function setBGTransparency(alphaValue) {
    effectData.bgState.bgTransparency = alphaValue;
    var bgAlphaShaderId = effectData.shadersIDs.bgAlpha;
    var invertedValue = 1. - alphaValue;
    Api.meshfxMsg("shaderVec4", 0, bgAlphaShaderId, invertedValue + " 0 0 0");
}

function setTextureTransparency(alphaValue) {
    effectData.bgState.textureTransparency = alphaValue;
    var bgTexAlphaShaderId = effectData.shadersIDs.bgTextureAlpha;
    Api.meshfxMsg("shaderVec4", 0, bgTexAlphaShaderId, alphaValue + " 0 0 0");
}

function rotateBg(angle) {
    effectData.bgState.currAngle = angle;
    setBgRotation(effectData.bgState.currAngle);
}

function scaleBg(scale) {
    effectData.bgState.currScale = scale;
    setBgScale(effectData.bgState.currScale);
}

function setBgRotation(angle) {
    if (effectData.meshesState.bgSeparationCreated || effectData.meshesState.bgSeparationTransparentCreated) {
        Api.print("setBgRotation - rotation set to " + angle);
        Api.meshfxMsg("shaderVec4", 0, effectData.shadersIDs.bgRotation, angle + " 0 0 0");
    }
}

function setBgScale(scale) {
    if (effectData.meshesState.bgSeparationCreated || effectData.meshesState.bgSeparationTransparentCreated) {
        Api.print("setBgScale - scale set to " + scale);
        Api.meshfxMsg("shaderVec4", 0, effectData.shadersIDs.bgScale, scale + " 0 0 0");
    }
}

function deleteBackground(modifyRecognizerFeatures) {
    if (effectData.meshesState.bgSeparationCreated && modifyRecognizerFeatures) {
        Api.print("deleteBackground - remove bg separation mesh");
        Api.meshfxMsg("del", effectData.reservedMeshId.bgSeparationMesh);
        
        effectData.meshesState.bgSeparationCreated = false;
    } else {
        Api.print("deleteBackground - cannot delete already deleted bg separation mesh");
    }
}

/** ------- Additional functions --------- **/

function makeString() {
    return Array.prototype.join.call(arguments, arguments[arguments.length -1]);
}

function onDataUpdate(param) {
    value = JSON.parse(param);

    if (typeof (value) == "object") {
        beautifyingProps = value;
    } else {
        beautifyingProps.morph_cheeks_str = value;
        beautifyingProps.morph_eyes_str = value;
        beautifyingProps.morph_nose_str = value;

        beautifyingProps.skin_soft_str = value;
        beautifyingProps.softlight_alpha = value;
        beautifyingProps.softlight_tex = 0;

        beautifyingProps.eyes_coloring_str = value;

        beautifyingProps.teeth_whitening_str = value;
    }

    updateEffect();
}

configure(effect);