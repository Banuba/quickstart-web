
function Effect() {
    var self = this;
    this.waitTime = 0;

    this.init = function () {
        Api.showRecordButton();
    };


    this.restart = function () {
        Api.meshfxReset();
        self.init();
    };

    this.faceActions = [];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordDiscardActions = [this.restart];
    this.videoRecordFinishActions = [];
}

configure(new Effect());
