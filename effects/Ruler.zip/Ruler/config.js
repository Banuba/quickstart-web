if ("enableRecognizerFeature" in bnb.scene) {
  bnb.scene.enableRecognizerFeature(bnb.FeatureID.RULER)
} else {
  bnb.log("The current version of BanubaSDK does not support Ruler feature.")
  bnb.log("Please update to the latest version of BanubaSDK.")
}