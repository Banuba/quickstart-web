bnb.scene.enableRecognizerFeature(bnb.FeatureID.PULSE);

let txtField = bnb.scene.getAssetManager().findImage("text");
txtField.asTextTexture().setText('');

function onDataUpdate(){
    if (bnb.heartRateMonitor.getDetectionProgress() < 100) {
        return "Heart rate calculation: " + bnb.heartRateMonitor.getDetectionProgress() + " %";
    } else {
        return "Heart rate: " + bnb.heartRateMonitor.getPulse().toFixed(0)  + " bpm";
    }
}